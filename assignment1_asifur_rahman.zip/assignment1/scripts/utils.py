import os
import pandas as pd


def process_dir(dir_path, index_col=None, transpose_flag=False, expected_r=None, expected_c=None ):
   f_count = 0
   for filename in os.listdir(dir_path):
      f_count+=1
      file = os.path.join(dir_path, filename)
      check_datasets(file, index_col=None, transpose_flag=False, expected_r=None, expected_c=None, file_count=f_count)


def check_datasets(file, index_col=None, transpose_flag=False, expected_r=None, expected_c=None, file_count=0):
   problemetic_file_col = []
   problemetic_file_row = []
   missing_value_file = []
   duplicated_data_file = []
  #  for filename in os.listdir(dir_path):
  #  file = os.path.join(dir_path, filename)
   if os.path.isfile(file):
      if index_col != None:
        dataset = pd.read_csv(file, index_col=index_col)
      else:
        dataset = pd.read_csv(file)
      if transpose_flag:
        dataset = dataset.T
      
      # if expected_r==None or expected_c==None: 
      if file_count == 1:
          expected_nrows = dataset.shape[0]
          expected_ncols = dataset.shape[1]
          row_names = dataset.index
          col_names = dataset.columns
      else:
          expected_nrows = expected_r
          expected_ncols = expected_c
          row_names = dataset.index
          col_names = dataset.columns
      if file_count>1:
          if dataset.shape[0] != expected_nrows:
            print('Number of rows do not match for ' + file)
            problemetic_file_row.append(file)
            print('Number of rows verified' + file)
          if dataset.shape[1] != expected_ncols:
            print('Number of cols do not match for ' + file)
            problemetic_file_col.append(file)
          if list(row_names) != list(dataset.index):
            print('Rows differ in ' + file)
          if list(col_names) != list(dataset.columns):
            print('Columns differ in ' + file)
       
      if dataset.isnull().values.any() == True:
        print('Missing values in ' + file)
        missing_value_file.append(file)
      else:
        print('No Missing value found')
        
      if dataset.duplicated().any():
        print('Duplicated rows in ' + file)
        duplicated_data_file.append(file)
      else:
        print('No duplicated row found')
    
   
