import fitparse
import numpy as np
from datetime import datetime
import os
import pandas as pd
import numpy as np



def get_sec(time_str):
    time_str = time_str.total_seconds()
    time_str = float(time_str)
    return time_str

def calculate_elapsed_time(s1, s2):
    s1 = str(s1)
    s2 = str(s2)
    FMT = '%Y-%m-%d %H:%M:%S'
    temp_time1 = datetime.strptime(s2, FMT)
    temp_time2 = datetime.strptime(s1, FMT)
    tdelta =  temp_time1 - temp_time2
    if tdelta.seconds>0:
      elapsed_time = get_sec(tdelta)
    else:
      tdelta =  temp_time2 - temp_time1
      elapsed_time = get_sec(tdelta)
    return elapsed_time

def same_loc(t, distance_vec):
    if (distance_vec[t]==distance_vec[t+1]):
        return True
    else:
        return False
    
def calculate_stop_time(prev_timestmp, curr_timestmp):
        stop_time=calculate_elapsed_time(prev_timestmp, curr_timestmp)
        return stop_time
    
    
def get_file_data(file_path, Weight=145, Age=25, athlete_id=None, category_id=None):
          fitfile = fitparse.FitFile(file_path)
          altitude = []
          cadence = []
          distance = []
          enhanced_altitude = []
          enhanced_speed = []
          heart_rate = []
          latitude_vec = []
          longitude_vec = []
          power = []
          speed = []
          timestamp = []

          prev_elevation = 0
          elevation_gain = 0
          elevation_loss = 0
          for record in fitfile.get_messages("record"):
            for data in record:
                if data.units:
                  # print(" * {}: {} ({})".format(data.name, data.value, data.units))
                  #****************************************************************
                  if data.name == "altitude":
                    if not data.value==None:
                        altitude.append(data.value)
                    else:
                        altitude.append(np.nan)
                  elif data.name =="cadence":
                    if not data.value==None:
                        cadence.append(data.value)
                    else:
                        cadence.append(np.nan)
                  elif data.name =="distance":
                    if not data.value==None:
                        distance.append(data.value)
                    else:
                        distance.append(np.nan)
                  elif data.name =="enhanced_altitude":
                    if not data.value==None:
                        enhanced_altitude.append(data.value)
                    else:
                        enhanced_altitude.append(np.nan)
                  elif data.name =="enhanced_speed":
                    if not data.value==None:
                        enhanced_speed.append(data.value)
                    else:
                        enhanced_speed.append(np.nan)
                  elif data.name =="heart_rate":
                    if not data.value==None:
                        heart_rate.append(data.value)
                    else:
                        heart_rate.append(np.nan)
                  elif data.name =="position_lat":
                    if not data.value==None:
                        lat=float(data.value)
                        # lat=float(data.value)*(180/2**31)
                        latitude_vec.append(lat)
                    else:
                        latitude_vec.append(np.nan)
                  elif data.name =="position_long":
                    if not data.value==None:
                        longt=float(data.value)
                        # longt=float(data.value)*(180/2**31)
                        longitude_vec.append(longt)
                    else:
                        longitude_vec.append(np.nan)
                  elif data.name =="power":
                    if not data.value==None:
                        power.append(data.value)
                    else:
                        power.append(np.nan)
                  elif data.name =="speed":
                    if not data.value==None:
                        speed.append(data.value)
                    else:
                        speed.append(np.nan)
                  elif data.name =="timestamp":
                    if not data.value==None:
                        timestamp.append(data.value)
                    else:
                        timestamp.append(np.nan)
                  #****************************************************************
                else:
                  # print(" * {}: {}".format(data.name, data.value))
                  #****************************************************************
                  if data.name == "altitude":
                    if not data.value==None:
                        altitude.append(data.value)
                    else:
                        altitude.append(np.nan)
                  elif data.name =="cadence":
                    if not data.value==None:
                        cadence.append(data.value)
                    else:
                        cadence.append(np.nan)
                  elif data.name =="distance":
                    if not data.value==None:
                        distance.append(data.value)
                    else:
                        distance.append(np.nan)
                  elif data.name =="enhanced_altitude":
                    if not data.value==None:
                        enhanced_altitude.append(data.value)
                    else:
                        enhanced_altitude.append(np.nan)
                  elif data.name =="enhanced_speed":
                    if not data.value==None:
                        enhanced_speed.append(data.value)
                    else:
                        enhanced_speed.append(np.nan)
                  elif data.name =="heart_rate":
                    if not data.value==None:
                        heart_rate.append(data.value)
                    else:
                        heart_rate.append(np.nan)
                  elif data.name =="position_lat":
                    if not data.value==None:
                        lat=float(data.value)
                        # lat=float(data.value)*(180/2**31)
                        latitude_vec.append(lat)
                    else:
                        latitude_vec.append(np.nan)
                  elif data.name =="position_long":
                    if not data.value==None:
                        longt=float(data.value)
                        # longt=float(data.value)*(180/2**31)
                        longitude_vec.append(longt)
                    else:
                        longitude_vec.append(np.nan)
                  elif data.name =="power":
                    if not data.value==None:
                        power.append(data.value)
                    else:
                        power.append(np.nan)
                  elif data.name =="speed":
                    if not data.value==None:
                       speed.append(data.value)
                    else:
                      speed.append(np.nan)
                  elif data.name =="timestamp":
                    if not data.value==None:
                        timestamp.append(data.value)
                    else:
                        timestamp.append(np.nan)
          #****************************************************************
    
          altitude = np.array(altitude)
          cadence = np.array(cadence)
          distance = np.array(distance)
          latitude_vec = np.array(latitude_vec)
          longitude_vec = np.array(longitude_vec)
          enhanced_altitude = np.array(enhanced_altitude)
          enhanced_speed = np.array(enhanced_speed)
          heart_rate = np.array(heart_rate)
          power = np.array(power)
          speed = 3.6*np.array(speed)
       
          total_stop_time = 0  
          tot_stop_time2 = 0
          for t in range(len(distance)-1):
                if same_loc(t, distance):
                      diff = calculate_stop_time(timestamp[t], timestamp[t+1])
                      total_stop_time +=diff
       
          elapsed_time = calculate_elapsed_time(timestamp[0], timestamp[len(timestamp)-1])
          moving_time = elapsed_time-total_stop_time
          elapsed_time = elapsed_time/60 #converting to minutes
          moving_time = moving_time/60 #converting to minutes
          distance = distance[len(distance)-1]/1000      # converting to kilometer
          tmp_avg_speed = (distance)/(moving_time/60)
          avg_speed = speed.mean()
          max_speed = max(speed)
         
            
          for i in range(len(altitude)-2):
            if altitude[i+1]<altitude[i]:
              descent = altitude[i]-altitude[i+1]
              elevation_loss+=descent
            elif altitude[i+1]>altitude[i]:
              ascent = altitude[i+1]-altitude[i]
              elevation_gain+=ascent
                
          calories = abs(((0.6309*heart_rate*60+0.09036*Weight+0.2017*Age)-55.0969)/4.184)    #KJ/Second
          calories = calories.mean()
          avg_hr = heart_rate.mean()
          max_hr = max(heart_rate)
          avg_cadence = sum(cadence)/np.count_nonzero(cadence)
          max_cadence = max(cadence)
          avg_power = power.mean()     
          calories = calories.mean()
          filename = file_path.split('data')[-1]
#           print(filename)
          if athlete_id==None:
                athlete_id=np.nan
          if category_id==None:
                category_id = np.nan
          Data ={"ID":None,
                 "activity_id":None,
                 "category_id":[category_id],
                 "athlete_id": [athlete_id],
                 "filename":[filename],
                 "timestamp": [timestamp[0]],
                 "distance": [distance],
                 "elapsed_time": [elapsed_time],
                 "moving_time": [moving_time],
                 "avg_speed": [avg_speed],
                 "max_speed": [max_speed],
                 "elevation_gain":[elevation_gain],
                 "elevation_loss":[elevation_loss],
                 "avg_hr":[avg_hr],
                 "max_hr":[max_hr],
                 "calories":[calories],
                 "avg_cadence":[avg_cadence],
                 "max_cadence":[max_cadence],
                 "avg_power":[avg_power]
          }
          return Data

 
def parse_data(file_dir, csv_dir, athlete_id=5):
      f_count = 0
      for filename in os.listdir(file_dir):
#           print(filename)
          file = os.path.join(file_dir, filename)
          if os.path.isfile(file):
                f_count+=1
                Data = get_file_data(file, athlete_id=athlete_id)
                Data["ID"]=f_count
                Data["activity_id"]=f_count
                if f_count==1:
                      df = pd.DataFrame(Data)
                else:
                      df_temp = pd.DataFrame(Data)
#                       df = df.append(df_temp, ignore_index = True)
                      df = pd.concat([df,df_temp])
#                 print(df)
#       print(f_count)
      df.set_index('ID', inplace=True)
      df.to_csv(csv_dir)
      print("File saved!!!", csv_dir)