import sklearn.datasets as datasets
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import sklearn.metrics as metrics
from sklearn.feature_selection import RFE
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from IPython.display import display
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import PolynomialFeatures
from sklearn.tree import DecisionTreeRegressor
import numpy as np


def plot_regression(reg_name, Y_train, train_pred_y, Y_test, test_pred_y):
    
    fig =plt.figure(figsize=(10,5),dpi=300)
    plt.subplot(1,2,1)
    ax=sns.scatterplot(x=range(len(Y_train)),y=Y_train, color="yellow", label="target", alpha=0.9)
    ax=sns.scatterplot(x=range(len(train_pred_y)),y=train_pred_y, color="blue", label="prediction", alpha=0.5)
    ax.legend()
    plt.title('Training Performance')
    plt.xlabel('No of instances')
    plt.ylabel('Average Power')
    
    plt.subplot(1,2,2)
    ax=sns.scatterplot(x=range(len(Y_test)),y=Y_test, color="yellow", label="target", alpha=0.9)
    ax=sns.scatterplot(x=range(len(test_pred_y)),y=test_pred_y, color="blue", label="prediction", alpha=0.5)
    ax.legend()
    plt.title('Testing Performance')
    plt.xlabel('No of instances')
    plt.ylabel('Average Power')
    plt.subplots_adjust(left=0.1,
                    bottom=0.1, 
                    right=0.9, 
                    top=0.9, 
                    wspace=0.5, 
                    hspace=0.5)
    fig.suptitle(reg_name, ha='center', fontsize=12)
    plt.show()
    
    
def linear_regression(X_train, Y_train, X_test, Y_test):
    lr = LinearRegression()
    trained_model = lr.fit(X_train, Y_train)
    
    train_pred_y = lr.predict(X_train)
    train_mse = metrics.mean_squared_error(Y_train, train_pred_y)
    train_R2 = metrics.r2_score(Y_train, train_pred_y)
    
    test_pred_y = lr.predict(X_test)
    test_mse = metrics.mean_squared_error(Y_test, test_pred_y)
    test_R2 = metrics.r2_score(Y_test, test_pred_y)
    print_performance_data("Linear Regression", train_mse, train_R2, test_mse,test_R2)
    plot_regression("Linear Regression",Y_train, train_pred_y, Y_test, test_pred_y)
    return trained_model, train_mse, train_R2, test_mse, test_R2


def DT_reg(X_train, Y_train, X_test, Y_test, max_depth=5, plot=True):
    dt_reg = DecisionTreeRegressor(max_depth=5)
    dt_reg_trained = dt_reg.fit(X_train, Y_train)
    train_pred_y = dt_reg.predict(X_train)
    train_mse = metrics.mean_squared_error(Y_train, train_pred_y)
    train_R2 = metrics.r2_score(Y_train, train_pred_y)
    
    test_pred_y = dt_reg.predict(X_test)
    test_mse = metrics.mean_squared_error(Y_test, test_pred_y)
    test_R2 = metrics.r2_score(Y_test, test_pred_y)
    if plot:
        print_performance_data("Decision Tree Regression", train_mse, train_R2, test_mse,test_R2)
        plot_regression("Decision Tree Regression",Y_train, train_pred_y, Y_test, test_pred_y)
    return dt_reg_trained, train_mse, train_R2, test_mse, test_R2


# def polynomial_reg(X_train, Y_train, X_test, Y_test):
#     poly_reg = PolynomialFeatures(degree = 2)
#     X_poly = poly_reg.fit_transform(X_train)
    
#     poly_reg_model = LinearRegression()
#     poly_reg_model.fit(X_poly, Y_train)
    
#     train_pred_y = poly_reg_model.predict(poly_reg.fit_transform(X_train))
#     train_mse = metrics.mean_squared_error(Y_train, train_pred_y)
#     train_R2 = metrics.r2_score(Y_train, train_pred_y)
    
#     test_pred_y = poly_reg_model.predict(poly_reg.fit_transform(X_test))
#     test_mse = metrics.mean_squared_error(Y_test, test_pred_y)
#     test_R2 = metrics.r2_score(Y_test, test_pred_y)

#     print_performance_data("Polynomial Regression", train_mse, train_R2, test_mse,test_R2)
#     plot_regression("Polynomial Regression",Y_train, train_pred_y, Y_test, test_pred_y)
#     return poly_reg_model, train_mse, train_R2, test_mse, test_R2

# def logistic_regression(X_train, Y_train, X_test, Y_test):
#     model = LogisticRegression(solver='liblinear', random_state=0)
#     trained_model = model.fit(X_train, Y_train)
    
#     train_pred_y = model.predict(X_train)
#     train_mse = metrics.mean_squared_error(Y_train, train_pred_y)
#     train_R2 = metrics.r2_score(Y_train, train_pred_y)
    
#     test_pred_y = model.predict(X_test)
#     test_mse = metrics.mean_squared_error(Y_test, test_pred_y)
#     test_R2 = metrics.r2_score(Y_test, test_pred_y)
#     print_performance_data("Logistic Regression", train_mse, train_R2, test_mse,test_R2)
#     plot_regression("Logistic Regression",Y_train, train_pred_y, Y_test, test_pred_y)
#     return trained_model, train_mse, train_R2, test_mse, test_R2

    
# def logistic_regression(X_train, Y_train, X_test, Y_test): 
def print_performance_data(reg_name, train_mse, train_R2, test_mse,test_R2):
    print("#"*len(reg_name))
    print(reg_name)
    print("#"*len(reg_name))
    print("Training Performance")
    print("-"*len(reg_name))
    print("MSE:", train_mse)
    print("R2 Score:", train_R2)
    print("-"*len(reg_name))
    print("\n")
    print("Testing Performance")
    print("-"*len(reg_name))
    print("MSE:", test_mse)
    print("R2 Score:", test_R2)
    print("-"*len(reg_name))

def split_data(training_data, testing_data):
#*****************************************
#         TRAINING DATA
#*****************************************
        X_train = training_data.loc[:, ~training_data.columns.isin(['activity_id', 'category_id', 'athlete_id', 'filename','timestamp'])]
        Y_train = training_data['avg_power']
#*****************************************

#*****************************************
#         TESTING DATA
#*****************************************
        X_test = testing_data.loc[:, ~testing_data.columns.isin(['activity_id', 'category_id', 'athlete_id', 'filename','timestamp'])]
        Y_test = testing_data['avg_power']
#*****************************************
        return X_train,Y_train,X_test,Y_test
     
    

def run_regression_comparison(X_train,Y_train,X_test,Y_test):
        trained_LR, train_mse_lr, train_R2_lr, test_mse_lr, test_R2_lr =linear_regression(X_train,Y_train,X_test,Y_test)
        
        trained_DT_reg, train_mse_dt, train_R2_dt, test_mse_dt, test_R2_dt = DT_reg(X_train,Y_train,X_test,Y_test)
        
        
        return trained_LR, trained_DT_reg
        
        
         